<?php

header('Location: ../../../');
exit;
