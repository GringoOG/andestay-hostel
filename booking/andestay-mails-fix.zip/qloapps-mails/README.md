# QloApps mail layout fixes (AndeStay) — v1.1.3

## Problem (seen in production)
Order confirmation email on mobile showed:
1. **Huge logo** (shop logo image displayed at natural size)
2. **Overlapping room headers** from the default 9-column booking table  
   (`Room Image / Room Description / Hotel / …`)

Gmail often strips `<style>` blocks, so wide tables collapse into unreadable text.

## Fix
- Logo forced to **100×100 px** (HTML `width`/`height` + nested table)
- Booking details = **fully stacked** label → value cards (no columns)
- Extra demands / services also stacked
- Templates sync into `/mails/{lang}/` **and** theme `mails/{lang}/` on module Save/Upgrade

## Deploy (recommended)

1. Upload `booking/qloapps-modules/payatproperty.zip` (module **1.1.3**)
2. QloApps BO → Modules → **Pay at property** → **Upgrade** (or reinstall)
3. Configure → **Save** (re-copies mail templates)
4. Advanced Parameters → Performance → **Clear cache**
5. Place a **new** test booking and open the new confirmation email

## Manual copy (FTP / SFTP)

Copy for each language `en`, `es`, `cs`:

| File | Destination |
|------|-------------|
| `order_conf.html` | `/mails/{lang}/` and `/themes/hotel-reservation-theme/mails/{lang}/` |
| `hotel_booking_cart_data.tpl` | same |
| `booking_extra_demands.tpl` | same |

Source folder: `booking/qloapps-mails/` or inside the module `mails/`.

## Note
Old emails already sent stay broken. Only **new** bookings pick up the new templates.
